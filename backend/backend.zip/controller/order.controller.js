const uploadImageToCloudinary = require("../config/UploadToClaudinary");
const Order = require("../models/order");

// Create a new order
const createOrder = async (req, res) => {
    try {
        const { fullName, phoneNumber, selectedBank, address, totalPrice, order } = req.body;
        const receipt = req.files?.[0];

        if (!receipt) {
            return res.status(400).json({ message: "Bank receipt is required" });
        }

        const imageUrl = await uploadImageToCloudinary(receipt);
        const newOrder = new Order({
            fullName,
            phoneNumber,
            address,
            selectedBank,
            totalPrice,
            order: JSON.parse(order),
            bankRecipt: imageUrl,
            order_status: 'pending',
        });

        const savedOrder = await newOrder.save();
        res.status(201).json(savedOrder);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Get all orders
const getAllOrders = async (req, res) => {
    try {
        const orders = await Order.find();
        res.status(200).json(orders);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Get a single order by ID
const getOrderById = async (req, res) => {
    try {
        const order = await Order.findById(req.params.id);
        if (!order) {
            return res.status(404).json({ message: "Order not found" });
        }
        res.status(200).json(order);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Update an order by ID
const updateOrder = async (req, res) => {
    try {
        const updatedOrder = await Order.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true }
        );

        if (!updatedOrder) {
            return res.status(404).json({ message: "Order not found" });
        }
        res.status(200).json(updatedOrder);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Update order status
const updateOrderStatus = async (req, res) => {
    try {
        const { order_status } = req.body;

        if (!['pending', 'accepted', 'delivered', 'cancelled'].includes(order_status)) {
            return res.status(400).json({ message: "Invalid order status" });
        }

        const updatedOrder = await Order.findById(req.params.id);

        if (!updatedOrder) {
            return res.status(404).json({ message: "Order not found" });
        }

        updatedOrder.order_status = order_status;

        await updatedOrder.save();
        res.status(200).json(updatedOrder);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Delete an order by ID
const deleteOrder = async (req, res) => {
    try {
        const deletedOrder = await Order.findByIdAndDelete(req.params.id);
        if (!deletedOrder) {
            return res.status(404).json({ message: "Order not found" });
        }
        res.status(200).json({ message: "Order deleted successfully" });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

module.exports = {
    createOrder,
    getAllOrders,
    getOrderById,
    updateOrder,
    updateOrderStatus,
    deleteOrder,
};
