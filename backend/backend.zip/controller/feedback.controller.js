const Feedback = require("../models/feedback");

// Create feedback
const createFeedback = async (req, res) => {
    try {
        const { name, phoneNumber, email, message } = req.body;

        // Create new feedback entry
        const feedback = new Feedback({ name, phoneNumber, email, message });
        await feedback.save();

        res.status(201).json({
            message: "Feedback submitted successfully",
            feedback,
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Get feedbacks
const getFeedbacks = async (req, res) => {
    try {
        const feedbacks = await Feedback.find();
        res.status(200).json(feedbacks);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

module.exports = {
    createFeedback,
    getFeedbacks,
};
